﻿login-azurermaccount

$DebugPreference = "Continue"
get-azurermvm 